import numpy as np
import matplotlib.pyplot as plt
from p1 import homogeneous_pixels, normalized_eight_point_alg, plot_epipolar_lines_on_images
from epipolar_utils import compute_rectified_image, get_data_from_txt_file, imread


def transform_points(homography, points):
    points = homogeneous_pixels(points) @ homography.T
    return points / points[:, 2, None]


'''
COMPUTE_EPIPOLE computes the epipole e in homogenous coordinates
given the fundamental matrix
Arguments:
    F - the Fundamental matrix solved for with normalized_eight_point_alg(points1, points2)

Returns:
    epipole - the homogenous coordinates [x y 1] of the epipole in the image
'''
def compute_epipole(F):
    u, _, _ = np.linalg.svd(F)
    epipole = u[:, -1]
    if abs(epipole[2]) <= np.finfo(float).eps:
        return np.array([epipole[0], epipole[1], 0.0])
    return epipole / epipole[2]

'''
COMPUTE_H computes a homography to map an epipole to infinity along the horizontal axis 
Arguments:
    e - the epipole
    im2 - the image
Returns:
    H - homography matrix
'''
def compute_H(e, im):
    height, width = im.shape[:2]
    center = np.array([[1, 0, -width / 2], [0, 1, -height / 2], [0, 0, 1]])
    x, y, w = center @ e
    radius = np.hypot(x, y)
    if radius == 0:
        raise ValueError("The centered epipole has no horizontal direction")
    sign = 1.0 if x >= 0 else -1.0
    c, s = sign * np.array([x, y]) / radius
    rotation = np.array([[c, s, 0], [-s, c, 0], [0, 0, 1]])
    project = np.eye(3)
    project[2, 0] = -w / (sign * radius)
    return np.linalg.solve(center, project @ rotation @ center)

'''
COMPUTE_MATCHING_HOMOGRAPHIES determines homographies H1 and H2 such that they
rectify a pair of images
Arguments:
    e2 - the second epipole
    F - the Fundamental matrix
    im2 - the second image
    points1 - N points in the first image that match with points2
    points2 - N points in the second image that match with points1
Returns:
    H1 - the homography associated with the first image
    H2 - the homography associated with the second image
'''
def compute_matching_homographies(e2, F, im2, points1, points2):
    H2 = compute_H(e2, im2)
    x, y, w = e2
    cross = np.array([[0, -w, y], [w, 0, -x], [-y, x, 0]])
    transfer = cross @ F + e2[:, None] * np.ones((1, 3))
    provisional = H2 @ transfer
    first = transform_points(provisional, points1)
    second = transform_points(H2, points2)
    affine = np.eye(3)
    affine[0] = np.linalg.lstsq(first, second[:, 0], rcond=None)[0]
    return affine @ provisional, H2

if __name__ == '__main__':
    # Read in the data
    im_set = 'data/set1'
    im1 = imread(im_set+'/image1.jpg')
    im2 = imread(im_set+'/image2.jpg')
    points1 = get_data_from_txt_file(im_set+'/pt_2D_1.txt')
    points2 = get_data_from_txt_file(im_set+'/pt_2D_2.txt')
    assert (points1.shape == points2.shape)

    F = normalized_eight_point_alg(points1, points2)
    # F is such that such that (points2)^T * F * points1 = 0, so e1 is e' and e2 is e
    e1 = compute_epipole(F.T)
    e2 = compute_epipole(F)
    print("e1", e1)
    print("e2", e2)

    # Find the homographies needed to rectify the pair of images
    H1, H2 = compute_matching_homographies(e2, F, im2, points1, points2)
    print('')

    # Transforming the images by the homographies
    new_points1 = H1.dot(points1.T)
    new_points2 = H2.dot(points2.T)
    new_points1 /= new_points1[2,:]
    new_points2 /= new_points2[2,:]
    new_points1 = new_points1.T
    new_points2 = new_points2.T
    rectified_im1, offset1 = compute_rectified_image(im1, H1)
    rectified_im2, offset2 = compute_rectified_image(im2, H2)
    new_points1 -= offset1 + (0,)
    new_points2 -= offset2 + (0,)

    # Plotting the image
    origin1 = np.array([[1, 0, -offset1[0]], [0, 1, -offset1[1]], [0, 0, 1]])
    origin2 = np.array([[1, 0, -offset2[0]], [0, 1, -offset2[1]], [0, 0, 1]])
    F_new = np.linalg.inv(origin2 @ H2).T @ F @ np.linalg.inv(origin1 @ H1)
    plot_epipolar_lines_on_images(new_points1, new_points2, rectified_im1, rectified_im2, F_new)
    plt.show()
