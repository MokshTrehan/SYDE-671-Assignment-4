import numpy as np
import matplotlib.pyplot as plt
from epipolar_utils import get_data_from_txt_file, scatter_3D_axis_equal
from p1 import homogeneous_pixels


def centered_measurements(points_im1, points_im2):
    first = homogeneous_pixels(points_im1)
    second = homogeneous_pixels(points_im2)
    if len(first) != len(second) or len(first) < 3:
        raise ValueError("At least three paired points are required")
    measurement = np.vstack((first[:, :2].T, second[:, :2].T))
    return measurement - measurement.mean(axis=1, keepdims=True)

'''
FACTORIZATION_METHOD The Tomasi and Kanade Factorization Method to determine
the 3D structure of the scene and the motion of the cameras.
Arguments:
    points_im1 - N points in the first image that match with points_im2
    points_im2 - N points in the second image that match with points_im1

    Both points_im1 and points_im2 are from the get_data_from_txt_file() method
Returns:
    structure - the structure matrix
    motion - the motion matrix
'''
def factorization_method(points_im1, points_im2):
    measurement = centered_measurements(points_im1, points_im2)
    u, singular_values, vh = np.linalg.svd(measurement, full_matrices=False)
    roots = np.sqrt(singular_values[:3])
    structure = roots[:, None] * vh[:3]
    motion = u[:, :3] * roots
    return structure, motion

if __name__ == '__main__':
    for im_set in ['data/set1', 'data/set1_subset']:
        # Read in the data
        points_im1 = get_data_from_txt_file(im_set + '/pt_2D_1.txt')
        points_im2 = get_data_from_txt_file(im_set + '/pt_2D_2.txt')
        points_3d = get_data_from_txt_file(im_set + '/pt_3D.txt')
        assert (points_im1.shape == points_im2.shape)

        # Run the Factorization Method
        structure, motion = factorization_method(points_im1, points_im2)
        print(im_set, "singular values:", np.linalg.svd(
            centered_measurements(points_im1, points_im2), compute_uv=False))

        # Plot the structure
        fig = plt.figure()
        ax = fig.add_subplot(121, projection = '3d')
        scatter_3D_axis_equal(structure[0,:], structure[1,:], structure[2,:], ax)
        ax.set_title('Factorization Method')
        ax = fig.add_subplot(122, projection = '3d')
        scatter_3D_axis_equal(points_3d[:,0], points_3d[:,1], points_3d[:,2], ax)
        ax.set_title('Ground Truth')

        plt.show()
