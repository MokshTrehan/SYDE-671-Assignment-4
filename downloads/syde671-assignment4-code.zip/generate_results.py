"""Reproduce the report figures and measurements from the supplied inputs."""
from __future__ import annotations

import json
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageOps

from epipolar_utils import compute_rectified_image, get_data_from_txt_file, imread
from p1 import (compute_distance_to_epipolar_lines, lls_eight_point_alg,
                normalize_points, normalized_eight_point_alg)
from p2 import compute_epipole, compute_matching_homographies, transform_points
from p3 import centered_measurements, factorization_method
from p4 import (estimate_RT_from_E, jacobian, linear_estimate_3d_point,
                nonlinear_estimate_3d_point, pose_cheirality_votes,
                reconstruct_statue, reprojection_error)

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
IMAGES = ROOT / "site" / "images"
RESULTS = ROOT / "results"
INK = "#182b42"
BLUE = "#174dab"
PLOT_COLORS = ("#20b9ff", "#ffcc36", "#f583e8", "#6ee7a0", "#ff8446",
               "#a8a2ff", "#f97d86", "#bded60", "#4be2de", "#ffe6a4")
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.labelcolor": INK, "axes.titlecolor": INK,
                     "xtick.color": INK, "ytick.color": INK})


def load_pair(name):
    folder = DATA / name
    images = [imread(folder / f"image{i}.jpg") for i in (1, 2)]
    points = [get_data_from_txt_file(folder / f"pt_2D_{i}.txt") for i in (1, 2)]
    return images, points


def save(fig, filename):
    fig.savefig(IMAGES / filename, dpi=150, facecolor="white", bbox_inches="tight", pad_inches=.09)
    plt.close(fig)


def sample_matches(first, count=len(PLOT_COLORS)):
    # Display readable, uniformly spaced ranks in vertical image coordinate.
    order = np.argsort(first[:, 1], kind="stable")
    return order[np.linspace(0, len(order) - 1, min(count, len(order))).round().astype(int)]


def plot_epipolar(ax, image, observations, lines, selected):
    h, w = image.shape[:2]
    ax.imshow(image, cmap="gray", vmin=0, vmax=255)
    for i, color in zip(selected, PLOT_COLORS):
        a, b, c = lines[i]
        if abs(b) >= abs(a):
            x = np.array([0, w - 1])
            ax.plot(x, -(a * x + c) / b, color=color, alpha=.85, lw=1)
        else:
            y = np.array([0, h - 1])
            ax.plot(-(b * y + c) / a, y, color=color, alpha=.85, lw=1)
        ax.scatter(*observations[i, :2], s=24, facecolor=color, edgecolor=INK,
                   linewidth=.65, zorder=4)
    ax.set(xlim=(-.5, w - .5), ylim=(h - .5, -.5))
    ax.set_axis_off()


def measure_epipolar():
    output = {}
    for name in ("set1", "set2"):
        images, (first, second) = load_pair(name)
        selected = sample_matches(first)
        fig, axes = plt.subplots(2, 2, figsize=(8.8, 9.15), layout="constrained")
        methods = (("linear", "Linear", lls_eight_point_alg),
                   ("normalized", "Normalized", normalized_eight_point_alg))
        row = {"matches": len(first)}
        for (method, label, estimate), ax_row in zip(methods, axes):
            F = estimate(first, second)
            distances = [compute_distance_to_epipolar_lines(first, second, F),
                         compute_distance_to_epipolar_lines(second, first, F.T)]
            singular = np.linalg.svd(F, compute_uv=False)
            np.testing.assert_allclose(singular[-1], 0, atol=1e-12)
            row[method] = {"F": F.tolist(), "distance_px": distances,
                           "singular_values": singular.tolist()}
            for index, (ax, obs, lines, image) in enumerate(zip(
                    ax_row, (first, second), (second @ F, first @ F.T), images), 1):
                plot_epipolar(ax, image, obs, lines, selected)
                ax.set_title(f"{label}, Image {index}  |  {distances[index-1]:.2f} px mean", pad=7)
        save(fig, f"{name}-epipolar.jpg")
        output[name] = row
    return output


def measure_rectification():
    images, (first, second) = load_pair("set1")
    F = normalized_eight_point_alg(first, second)
    e1, e2 = compute_epipole(F.T), compute_epipole(F)
    np.testing.assert_allclose(F @ e1, 0, atol=1e-10)
    np.testing.assert_allclose(F.T @ e2, 0, atol=1e-10)
    H1, H2 = compute_matching_homographies(e2, F, images[1], first, second)
    for H, e in ((H1, e1), (H2, e2)):
        mapped = H @ e
        np.testing.assert_allclose(mapped[1:] / mapped[0], 0, atol=1e-10)
    first_w, second_w = transform_points(H1, first), transform_points(H2, second)
    warped = [compute_rectified_image(im, H) for im, H in zip(images, (H1, H2))]
    ymin = min(offset[1] for _, offset in warped)
    ymax = max(offset[1] + image.shape[0] for image, offset in warped)
    fig, axes = plt.subplots(1, 2, figsize=(11.6, 6.0), layout="constrained",
                             gridspec_kw={"width_ratios": [im.shape[1] for im, _ in warped]})
    chosen = sample_matches(first_w, 7)
    for i, (ax, (im, (x, y)), points) in enumerate(zip(axes, warped, (first_w, second_w)), 1):
        h, w = im.shape
        ax.imshow(im, cmap="gray", vmin=0, vmax=255,
                  extent=(x-.5, x+w-.5, y+h-.5, y-.5))
        ax.set_facecolor("#101926")
        for index, color in zip(chosen, PLOT_COLORS):
            y_guide = (first_w[index, 1] + second_w[index, 1]) / 2
            ax.axhline(y_guide, color=color, lw=.9, alpha=.86)
            ax.scatter(*points[index, :2], c=color, s=23, edgecolor=INK, linewidth=.65)
        ax.set(xlim=(x-.5, x+w-.5), ylim=(ymax-.5, ymin-.5), title=f"Rectified Image {i}")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
    save(fig, "rectified-pair.jpg")
    for i, (image, _) in enumerate(warped, 1):
        Image.fromarray(image).save(IMAGES / f"rectified-{i}.png")
    before = np.abs(first[:, 1] - second[:, 1])
    after = np.abs(first_w[:, 1] - second_w[:, 1])
    assert np.median(after) < 1 and np.mean(after) < np.mean(before) / 10

    def summarize(a):
        return {"mean": float(np.mean(a)), "median": float(np.median(a)),
                "rms": float(np.sqrt(np.mean(a*a))), "p95": float(np.percentile(a, 95)),
                "max": float(np.max(a))}
    return {"epipoles": [e1.tolist(), e2.tolist()], "H1": H1.tolist(), "H2": H2.tolist(),
            "before_px": summarize(before), "after_px": summarize(after),
            "raster_offsets": [list(map(int, offset)) for _, offset in warped],
            "dimensions_hw": [list(im.shape) for im, _ in warped]}


def plot_factorization(truth, aligned, name):
    # Use ground-truth principal axes only for the diagnostic camera viewpoint.
    # The fitted similarity and both displayed point sets are in common units.
    _, _, basis = np.linalg.svd(truth, full_matrices=False)
    actual, estimated = truth @ basis.T, aligned @ basis.T
    pairs = [(0, 1, "First two principal axes"), (0, 2, "Depth profile")]
    fig = plt.figure(figsize=(13.0, 4.15), layout="constrained")
    ax3d = fig.add_subplot(131, projection="3d")
    ax3d.scatter(*actual.T, s=31, facecolors="white", edgecolors=INK,
                 depthshade=False, linewidths=.85)
    ax3d.scatter(*estimated.T, s=18, c="#2364cd", marker="x",
                 depthshade=False, linewidths=1.0)
    for a, p in zip(actual, estimated):
        ax3d.plot(*np.stack([a, p], axis=1), color="#b9c8dd", lw=.7)
    ax3d.set_title("3D view")
    ax3d.view_init(25, -58)
    ax3d.set_proj_type("ortho")
    joint = np.vstack([actual, estimated])
    centers = (joint.max(axis=0) + joint.min(axis=0)) / 2
    half_span = np.ptp(joint, axis=0).max() * .55
    ax3d.set(xlim=centers[0] + np.array([-half_span, half_span]),
             ylim=centers[1] + np.array([-half_span, half_span]),
             zlim=centers[2] + np.array([-half_span, half_span]))
    ax3d.set_box_aspect((1, 1, 1))
    ax3d.set_axis_off()
    axes = (fig.add_subplot(132), fig.add_subplot(133))
    for (a, b, title), ax in zip(pairs, axes):
        for t, p in zip(actual, estimated):
            ax.plot([t[a], p[a]], [t[b], p[b]], color="#b9c8dd", lw=.85, zorder=1)
        ax.scatter(actual[:, a], actual[:, b], s=38, facecolors="white", edgecolors=INK,
                   linewidths=1.1, label="Ground truth", zorder=2)
        ax.scatter(estimated[:, a], estimated[:, b], s=19, c="#2364cd", marker="x",
                   linewidths=1.1, label="Reconstruction", zorder=3)
        ax.set_title(title)
        ax.set_xlabel("Principal axis 1")
        ax.set_ylabel(f"Principal axis {b+1}")
        ax.set_aspect("equal", adjustable="datalim")
        ax.set_axisbelow(True)
        ax.grid(color="#e1e8f1")
    axes[0].legend(loc="best", fontsize=8, framealpha=.96)
    save(fig, f"{name}-factorization.png")


def measure_factorization():
    output = {}
    for name in ("set1", "set1_subset"):
        _, (first, second) = load_pair(name)
        truth = get_data_from_txt_file(DATA / name / "pt_3D.txt")
        truth -= truth.mean(axis=0)
        measurement = centered_measurements(first, second)
        singular = np.linalg.svd(measurement, compute_uv=False)
        structure, motion = factorization_method(first, second)
        np.testing.assert_allclose(np.linalg.norm(measurement - motion @ structure),
                                   singular[-1], rtol=1e-12)
        recovered = structure.T
        u, cov, vh = np.linalg.svd(recovered.T @ truth)
        signs = np.array([1, 1, np.linalg.det(u @ vh)])
        rotation = (u * signs) @ vh
        scale = np.dot(cov, signs) / np.sum(recovered**2)
        aligned = scale * recovered @ rotation
        affine = np.linalg.lstsq(recovered, truth, rcond=None)[0]
        truth_s = np.linalg.svd(truth, compute_uv=False)
        plot_factorization(truth, aligned, name)
        output[name] = {
            "points": len(truth), "singular_values": singular.tolist(),
            "sigma4_over_sigma3": float(singular[3] / singular[2]),
            "truth_thickness_ratio": float(truth_s[2] / truth_s[0]),
            "similarity_relative_rms": float(np.linalg.norm(aligned-truth) / np.linalg.norm(truth)),
            "affine_relative_rms": float(np.linalg.norm(recovered @ affine-truth) / np.linalg.norm(truth)),
        }
    return output


def load_npy(path):
    # The trusted course starter uses legacy Python 2 object-array files.
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=r"Reading .*additional header parsing")
        return np.load(path, allow_pickle=True, encoding="latin1")


def statue_figures(paths, clouds):
    tiles = []
    thumb_w, thumb_h = 236, 184
    for path in paths:
        with Image.open(path) as im:
            tiles.append(ImageOps.contain(im.convert("RGB"), (thumb_w, thumb_h)))
    strip = Image.new("RGB", (5*thumb_w+4*12, thumb_h), "#f1f5fa")
    for i, im in enumerate(tiles):
        strip.paste(im, (i*(thumb_w+12)+(thumb_w-im.width)//2, (thumb_h-im.height)//2))
    strip.save(IMAGES / "statue-sources.jpg", quality=94)

    cloud = np.concatenate(clouds)
    limits = np.array([[-5, 5], [-5, 5], [0, 10]])
    inside = ((cloud >= limits[:, 0]) & (cloud <= limits[:, 1])).all(axis=1)
    displayed = cloud[inside]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.6), layout="constrained")
    for ax, (title, elevation, azimuth) in zip(axes, (
            ("Frontal view", -100, 90), ("Oblique view", -80, 124))):
        elev, azim = np.radians([elevation, azimuth])
        right = np.array([-np.sin(azim), np.cos(azim), 0])
        up = np.array([-np.cos(azim) * np.sin(elev),
                       -np.sin(azim) * np.sin(elev), np.cos(elev)])
        projected = displayed @ np.array([right, up]).T
        center = (projected.max(axis=0) + projected.min(axis=0)) / 2
        ax.scatter(*projected.T, c=displayed[:, 2], cmap="viridis_r", vmin=3.0, vmax=6.0,
                   s=.55, alpha=.65, linewidths=0)
        ax.set(xlim=center[0] + np.array([-2.40, 2.40]),
               ylim=center[1] + np.array([-2.40, 2.40]))
        ax.set_aspect("equal")
        ax.set_title(title, fontsize=12)
        ax.set_axis_off()
    save(fig, "statue-reconstruction.jpg")
    # Retain every triangulated track for independent inspection.
    np.savez_compressed(RESULTS / "statue-points.npz",
                        **{f"pair_{i+1}": c for i, c in enumerate(clouds)})
    return int(inside.sum()), int(np.isfinite(cloud).all(axis=1).sum())


def measure_statue():
    statue = DATA / "statue"
    paths = sorted((statue / "images").glob("*.jpg"))
    sparse = load_npy(statue / "matches_subset.npy")[0]
    fundamental = load_npy(statue / "fundamental_matrices.npy")[0]
    dense = load_npy(statue / "dense_matches.npy")
    H, W = imread(paths[0]).shape[:2]
    focal = 719.5459
    K = np.diag([focal, focal, 1])
    E = K.T @ fundamental[0] @ K
    observations = sparse[0].T.reshape(-1, 2, 2)
    candidates, votes = pose_cheirality_votes(E, observations, K)
    selected = estimate_RT_from_E(E, observations, K)
    np.testing.assert_allclose(np.linalg.det(candidates[:, :, :3]), 1, atol=1e-12)
    np.testing.assert_allclose(np.linalg.norm(candidates[:, :, 3], axis=1), 1, atol=1e-12)
    provided_RT = np.array([[.9736,-.0988,-.2056,.9994],
                            [.1019,.9948,.0045,-.0089],
                            [.2041,-.0254,.9786,.0331]])
    np.testing.assert_allclose(selected, provided_RT, atol=5e-5)

    cameras = K @ np.array([np.eye(3, 4), provided_RT])
    match = observations[0]
    reference_xyz = np.array([.6774, -1.1029, 4.6621])
    fitted_xyz = linear_estimate_3d_point(match, cameras)
    residual = reprojection_error(reference_xyz, match, cameras)
    reference_residual = np.array([-.0095458, -.5171407, .0059307, .501631])
    derivative = jacobian(reference_xyz, cameras)
    h = 1e-5
    finite_difference = np.column_stack([
        (reprojection_error(reference_xyz+d, match, cameras)
         - reprojection_error(reference_xyz-d, match, cameras)) / (2*h)
        for d in h*np.eye(3)
    ])
    np.testing.assert_allclose(derivative, finite_difference, atol=1e-7)
    np.testing.assert_allclose(residual, reference_residual, atol=1e-6)

    unit_cameras = load_npy(DATA / "unit_test_camera_matrix.npy")
    unit_matches = load_npy(DATA / "unit_test_image_matches.npy")
    costs = []
    for triangulate in (linear_estimate_3d_point, nonlinear_estimate_3d_point):
        xyz = triangulate(unit_matches, unit_cameras)
        costs.append(float(np.linalg.norm(reprojection_error(xyz, unit_matches, unit_cameras))))
    assert costs[1] < costs[0]

    merged, clouds = reconstruct_statue(sparse, dense, fundamental, focal, W, H)
    displayed, finite = statue_figures(paths, clouds)
    assert len(merged.motion) == len(paths) == 5
    assert displayed > 30000
    return {"focal_length": focal, "candidates": candidates.tolist(), "votes": votes.tolist(),
            "RT": selected.tolist(), "statue_images": [p.stem for p in paths],
            "sparse_matches_per_pair": [a.shape[1] for a in sparse],
            "dense_matches_per_pair": [len(c) for c in clouds],
            "merged_sparse_tracks": int(merged.structure.shape[0]),
            "finite": finite, "displayed": displayed, "reprojection_l2_before_after_px": costs,
            "dlt": fitted_xyz.tolist(),
            "dlt_delta_l1": float(np.abs(fitted_xyz-reference_xyz).sum()),
            "residual_delta_l1": float(np.abs(residual-reference_residual).sum()),
            "jacobian_fd_max_abs": float(np.max(np.abs(derivative-finite_difference))),
            "max_candidate_reference_difference": float(np.max(np.abs(selected-provided_RT)))}


def synthetic_check():
    rng = np.random.default_rng(671)
    xyz = rng.uniform([-1, -.6, 3], [1, .6, 7], size=(8, 3))
    K = np.array([[700, 0, 260], [0, 700, 252], [0, 0, 1]])
    cameras = K @ np.array([np.eye(3, 4), np.column_stack([np.eye(3), [1, .2, .1]])])
    screen = np.column_stack([xyz, np.ones(len(xyz))]) @ cameras.transpose(0, 2, 1)
    screen = screen / screen[..., 2, None]
    for estimate in (lls_eight_point_alg, normalized_eight_point_alg):
        matrix = estimate(*screen)
        assert compute_distance_to_epipolar_lines(*screen, matrix) < 1e-8
    for x, pair in zip(xyz, screen.transpose(1, 0, 2)):
        np.testing.assert_allclose(linear_estimate_3d_point(pair[:, :2], cameras), x, atol=1e-10)
    affine1, affine2 = xyz @ rng.normal(size=(3, 2)), xyz @ rng.normal(size=(3, 2))
    measurement = centered_measurements(affine1, affine2)
    structure, motion = factorization_method(affine1, affine2)
    np.testing.assert_allclose(motion @ structure, measurement, atol=1e-12)
    norm, _ = normalize_points(screen[0])
    np.testing.assert_allclose(norm[:, :2].mean(axis=0), 0, atol=1e-12)
    np.testing.assert_allclose(np.linalg.norm(norm[:, :2], axis=1).mean(), np.sqrt(2))
    return "passed"


def main():
    IMAGES.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    data = {"synthetic_geometry": synthetic_check(), "p1": measure_epipolar(),
            "p2": measure_rectification(), "p3": measure_factorization(), "p4": measure_statue()}
    (RESULTS / "measurements.json").write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    for name, result in data.items():
        print(name, result if name == "synthetic_geometry" else "complete", flush=True)


if __name__ == "__main__":
    main()
