import numpy as np
import matplotlib.pyplot as plt
from epipolar_utils import get_data_from_txt_file, imread


def homogeneous_pixels(points):
    """Return finite pixel coordinates with a unit homogeneous component."""
    points = np.asarray(points, dtype=float)
    if points.ndim != 2 or points.shape[1] not in (2, 3):
        raise ValueError("Expected an N-by-2 or N-by-3 point array")
    if points.shape[1] == 2:
        return np.column_stack((points, np.ones(len(points))))
    if np.any(points[:, 2] == 0):
        raise ValueError("Point coordinates must be finite")
    return points / points[:, 2, None]


def normalize_points(points):
    pixels = homogeneous_pixels(points)
    center = pixels[:, :2].mean(axis=0)
    radius = np.linalg.norm(pixels[:, :2] - center, axis=1).mean()
    if radius == 0:
        raise ValueError("Cannot normalize coincident points")
    scale = np.sqrt(2.0) / radius
    transform = np.array([[scale, 0, -scale * center[0]],
                          [0, scale, -scale * center[1]],
                          [0, 0, 1]])
    return pixels @ transform.T, transform


def canonical_matrix(matrix):
    """Choose a reproducible norm and sign for a projective matrix."""
    pivot = matrix.flat[np.argmax(np.abs(matrix))]
    return matrix * (np.sign(pivot) / np.linalg.norm(matrix))


'''
LLS_EIGHT_POINT_ALG  computes the fundamental matrix from matching points using 
linear least squares eight point algorithm
Arguments:
    points1 - N points in the first image that match with points2
    points2 - N points in the second image that match with points1

    Both points1 and points2 are from the get_data_from_txt_file() method
Returns:
    F - the fundamental matrix such that (points2)^T * F * points1 = 0
Please see lecture notes and slides to see how the linear least squares eight
point algorithm works
'''
def lls_eight_point_alg(points1, points2):
    first = homogeneous_pixels(points1)
    second = homogeneous_pixels(points2)
    if len(first) != len(second) or len(first) < 8:
        raise ValueError("At least eight paired points are required")

    # Row-major vec(F) contracts with the flattened outer product p2 p1^T.
    design = (second[:, :, None] * first[:, None, :]).reshape(-1, 9)
    _, _, vh = np.linalg.svd(design, full_matrices=len(design) == 8)
    matrix = vh[-1].reshape(3, 3)
    u, singular_values, vh = np.linalg.svd(matrix)
    singular_values[-1] = 0.0
    return canonical_matrix((u * singular_values) @ vh)

'''
NORMALIZED_EIGHT_POINT_ALG  computes the fundamental matrix from matching points
using the normalized eight point algorithm
Arguments:
    points1 - N points in the first image that match with points2
    points2 - N points in the second image that match with points1

    Both points1 and points2 are from the get_data_from_txt_file() method
Returns:
    F - the fundamental matrix such that (points2)^T * F * points1 = 0
Please see lecture notes and slides to see how the normalized eight
point algorithm works
'''
def normalized_eight_point_alg(points1, points2):
    first, transform1 = normalize_points(points1)
    second, transform2 = normalize_points(points2)
    normalized = lls_eight_point_alg(first, second)
    return canonical_matrix(transform2.T @ normalized @ transform1)

'''
PLOT_EPIPOLAR_LINES_ON_IMAGES given a pair of images and corresponding points,
draws the epipolar lines on the images
Arguments:
    points1 - N points in the first image that match with points2
    points2 - N points in the second image that match with points1
    im1 - a HxW(xC) matrix that contains pixel values from the first image 
    im2 - a HxW(xC) matrix that contains pixel values from the second image 
    F - the fundamental matrix such that (points2)^T * F * points1 = 0

    Both points1 and points2 are from the get_data_from_txt_file() method
Returns:
    Nothing; instead, plots the two images with the matching points and
    their corresponding epipolar lines. See Figure 1 within the problem set
    handout for an example
'''
def plot_epipolar_lines_on_images(points1, points2, im1, im2, F):

    def plot_epipolar_lines_on_image(points1, points2, im, F):
        im_height = im.shape[0]
        im_width = im.shape[1]
        lines = F.T.dot(points2.T)
        plt.imshow(im, cmap='gray')
        for line in lines.T:
            a,b,c = line
            xs = [1, im.shape[1]-1]
            ys = [(-c-a*x)/b for x in xs]
            plt.plot(xs, ys, 'r')
        for i in range(points1.shape[0]):
            x,y,_ = points1[i]
            plt.plot(x, y, '*b')
        plt.axis([0, im_width, im_height, 0])

    # We change the figsize because matplotlib has weird behavior when 
    # plotting images of different sizes next to each other. This
    # fix should be changed to something more robust.
    new_figsize = (8 * (float(max(im1.shape[1], im2.shape[1])) / min(im1.shape[1], im2.shape[1]))**2 , 6)
    fig = plt.figure(figsize=new_figsize)
    plt.subplot(121)
    plot_epipolar_lines_on_image(points1, points2, im1, F)
    plt.axis('off')
    plt.subplot(122)
    plot_epipolar_lines_on_image(points2, points1, im2, F.T)
    plt.axis('off')

'''
COMPUTE_DISTANCE_TO_EPIPOLAR_LINES  computes the average distance of a set a 
points to their corresponding epipolar lines. Compute just the average distance
from points1 to their corresponding epipolar lines (which you get from points2).
Arguments:
    points1 - N points in the first image that match with points2
    points2 - N points in the second image that match with points1
    F - the fundamental matrix such that (points2)^T * F * points1 = 0

    Both points1 and points2 are from the get_data_from_txt_file() method
Returns:
    average_distance - the average distance of each point to the epipolar line
'''
def compute_distance_to_epipolar_lines(points1, points2, F):
    first = homogeneous_pixels(points1)
    second = homogeneous_pixels(points2)
    lines = second @ F
    distances = np.abs(np.einsum("ij,ij->i", first, lines))
    norms = np.linalg.norm(lines[:, :2], axis=1)
    if np.any(norms == 0):
        raise ValueError("An epipolar line has no finite point-to-line distance")
    return float(np.mean(distances / norms))

if __name__ == '__main__':
    for im_set in ['data/set1', 'data/set2']:
        print('-'*80)
        print("Set:", im_set)
        print('-'*80)

        # Read in the data
        im1 = imread(im_set+'/image1.jpg')
        im2 = imread(im_set+'/image2.jpg')
        points1 = get_data_from_txt_file(im_set+'/pt_2D_1.txt')
        points2 = get_data_from_txt_file(im_set+'/pt_2D_2.txt')
        assert (points1.shape == points2.shape)

        # Running the linear least squares eight point algorithm
        F_lls = lls_eight_point_alg(points1, points2)
        print("Fundamental Matrix from LLS  8-point algorithm:\n", F_lls)
        print("Distance to lines in image 1 for LLS:", \
            compute_distance_to_epipolar_lines(points1, points2, F_lls))
        print("Distance to lines in image 2 for LLS:", \
            compute_distance_to_epipolar_lines(points2, points1, F_lls.T))

        # Running the normalized eight point algorithm
        F_normalized = normalized_eight_point_alg(points1, points2)

        pFp = [points2[i].dot(F_normalized.dot(points1[i])) 
            for i in range(points1.shape[0])]
        print("p'^T F p =", np.abs(pFp).max())
        print("Fundamental Matrix from normalized 8-point algorithm:\n", \
            F_normalized)
        print("Distance to lines in image 1 for normalized:", \
            compute_distance_to_epipolar_lines(points1, points2, F_normalized))
        print("Distance to lines in image 2 for normalized:", \
            compute_distance_to_epipolar_lines(points2, points1, F_normalized.T))

        # Plotting the epipolar lines
        plot_epipolar_lines_on_images(points1, points2, im1, im2, F_lls)
        plot_epipolar_lines_on_images(points1, points2, im1, im2, F_normalized)

        plt.show()
