"""Render the Assignment 4 website from its measured results."""
import html
import json
import shutil
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent
SITE = ROOT / "site"
PDF = "syde671-assignment4-report.pdf"
CODE = "syde671-assignment4-code.zip"


def figure(file, number, alt, caption, classes="", figure_id=""):
    with Image.open(SITE / "images" / file) as image:
        width, height = image.size
    path = f"images/{file}"
    id_attr = f' id="{figure_id}"' if figure_id else ""
    return (f'<figure class="{classes}"{id_attr}><a class="image-link" href="{path}" '
            f'aria-label="Enlarge figure {number}"><img src="{path}" width="{width}" height="{height}" '
            f'alt="{html.escape(alt, quote=True)}"></a>'
            f'<figcaption><span class="fig-number">Figure {number}.</span> {caption}</figcaption></figure>')


def matrix(label, values, precision=8):
    formatted = "\n".join("  ".join(f"{value: .{precision}f}" for value in row)
                          for row in values)
    return f'<article class="matrix"><h3>{label}</h3><pre>{formatted}</pre></article>'


def table(headers, rows):
    header = "".join(f'<th scope="col">{cell}</th>' for cell in headers)
    content = "".join(
        "<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows)
    return f'<div class="table-scroll"><table><thead><tr>{header}</tr></thead><tbody>{content}</tbody></table></div>'


def section_title(problem, title):
    return f'<div class="section-title"><span>{problem}</span><h2>{title}</h2></div>'


def make_report(data):
    p1, p2, p3, p4 = (data[k] for k in ("p1", "p2", "p3", "p4"))
    p1_rows, matrices = [], []
    for key, record in p1.items():
        set_label = key.replace("set", "Set ")
        for method, label in (("linear", "Linear"), ("normalized", "Normalized")):
            result = record[method]
            p1_rows.append((set_label, record["matches"], label,
                            *(f"{d:.4f}" for d in result["distance_px"])))
            matrices.append(matrix(f"{set_label} · {label}", result["F"], 9))
    rect_rows = [(label, f'{p2["before_px"][key]:.3f}', f'{p2["after_px"][key]:.3f}')
                 for key, label in (("mean", "Mean"), ("median", "Median"), ("rms", "RMS"),
                                    ("p95", "95th percentile"), ("max", "Maximum"))]
    factor_rows = [(label, record["points"], *(f"{v:.4f}" for v in record["singular_values"]),
                    f'{record["sigma4_over_sigma3"]:.3f}')
                   for label, record in zip(("Full set", "Subset"), p3.values())]
    full, subset = p3.values()
    before, after = p2["before_px"], p2["after_px"]
    dlt, refined = p4["reprojection_l2_before_after_px"]
    vote_table = table(("Pose candidate", "Positive in both views"), [
        (i, f'{v} / {p4["sparse_matches_per_pair"][0]}') for i, v in enumerate(p4["votes"], 1)])
    epipoles = " and ".join("(" + ", ".join(f"{v:.4f}" for v in p) + ")"
                            for p in p2["epipoles"])
    cloud_caption = (f'{p4["displayed"]:,} triangulated points shown at the same scale from two '
                     'orthographic viewpoints. Color encodes depth in the reconstruction coordinate frame, with yellow nearer and purple farther.')
    pair_1 = figure("set1-epipolar.jpg", 1, "Set 1 toy house stereo pair with epipolar lines",
                    "Set 1. Linear estimates miss image features by tens of pixels. With normalization, the dots sit close to the matching lines in both images.")
    pair_2 = figure("set2-epipolar.jpg", 2, "Set 2 color stereo pair with epipolar lines",
                    "Set 2. The same ten matches are shown for both estimators. Across all 46 matches, the normalized estimates average below one pixel in both directions.")
    rectified = figure("rectified-pair.jpg", 3, "Rectified toy house stereo images sharing horizontal scanlines",
                       "Both rectified images use a common vertical coordinate and the same pixel scale. Each guide marks the midpoint of a selected pair of transformed vertical coordinates. Black areas lie outside the input photographs.")
    full_factorization = figure("set1-factorization.png", 4,
                                "Full-set 3D reconstruction and ground truth with planar projections",
                                "All 37 points after a fitted rotation and uniform scale. Corresponding points are joined by thin lines. The two projections show the overall shape and depth.")
    subset_factorization = figure("set1_subset-factorization.png", 5,
                                  "Subset reconstruction showing spurious depth relative to the nearly planar ground truth",
                                  "The 18-point subset. The depth profile shows the small out-of-plane extent of the reference points and the stronger variation in recovered depth.")
    sources = figure("statue-sources.jpg", 6, "Five supplied photographs of the statue from different camera positions",
                     "Statue source images B21 to B25, in acquisition order. The camera sees different amounts of the head, shoulders and pedestal as it moves.")
    cloud = figure("statue-reconstruction.jpg", 7, "Frontal and oblique projections of the reconstructed statue cloud",
                   cloud_caption, "cloud", "final-plot")

    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="SYDE 671 Assignment 4 report covering epipolar geometry, rectification, affine factorization, and projective structure from motion.">
<title>SYDE 671 · Assignment 4 · Moksh Trehan</title>
<link rel="stylesheet" href="style.css">
<script src="report.js" defer></script>
</head>
<body>
<a class="skip-link" href="#overview">Skip to report</a>
<header class="masthead">
  <a class="wordmark" href="#overview">SYDE 671 <span>/ Assignment 4</span></a>
  <nav aria-label="Report navigation">
    <a href="#fundamental">Fundamental matrix</a><a href="#rectification">Rectification</a>
    <a href="#factorization">Factorization</a><a href="#triangulation">Triangulation</a>
    <a href="downloads/{PDF}">Complete PDF ↗</a>
  </nav>
</header>
<main>
<section class="cover" id="overview">
  <div class="cover-grid">
    <div>
      <p class="eyebrow">SYDE 671 / Assignment 4 / Fall 2026</p>
      <h1>Two-view geometry.<br><em>From images to 3D.</em></h1>
      <p class="lede">Fundamental matrices, stereo rectification, affine factorization, and projective reconstruction.</p>
      <p class="byline">Moksh Trehan · November 15, 2026</p>
    </div>
    <figure class="cover-preview"><a href="#final-plot"><img src="images/statue-reconstruction.jpg" alt="Frontal and oblique views of a reconstructed statue"></a><figcaption><a href="#final-plot">View the statue reconstruction ↓</a></figcaption></figure>
  </div>
  <div class="stats">
    <div><strong>&lt; 0.90 px</strong><span>Mean epipolar distance in every normalized fit</span></div>
    <div><strong>{before["median"]:.2f} → {after["median"]:.2f} px</strong><span>Median vertical mismatch after rectifying Set 1</span></div>
    <div><strong>{p4["finite"]:,} points</strong><span>Triangulated across three dense stereo pairs</span></div>
  </div>
  <p>Normalization improves the fundamental matrix on both supplied stereo pairs. The fitted epipolar geometry then makes the toy-house pair directly comparable along horizontal scanlines. Affine factorization recovers the broad 3D layout, but depth becomes poorly constrained in the near-planar subset. Projective triangulation and the supplied camera-merging pipeline recover the front of the statue from five photographs.</p>
  <div class="contents" aria-label="Contents">
    <a href="#fundamental">1 · Fundamental matrix estimation</a>
    <a href="#rectification">2 · Matching homographies and rectification</a>
    <a href="#factorization">3 · Affine structure from motion</a>
    <a href="#triangulation">4 · Projective triangulation</a>
    <a href="#statue">Statue reconstruction and reproducibility</a>
  </div>
  <div class="downloads"><a href="downloads/{PDF}">Complete PDF</a><a href="downloads/{CODE}">Code ZIP</a><a href="downloads/measurements.json">Measurements</a></div>
</section>

<section class="report-section" id="fundamental">
  {section_title("1(a–f)", "Fundamental matrix estimation")}
  <p>Let <i>p</i><sub>1</sub> and <i>p</i><sub>2</sub> be matching homogeneous pixel coordinates. The convention is <i>p</i><sub>2</sub><sup>⊤</sup><i>Fp</i><sub>1</sub> = 0, so <i>Fp</i><sub>1</sub> is the line in Image 2.</p>
  <h3>Linear and normalized eight-point fits</h3>
  <p>Each match contributes one row to the design matrix, formed by flattening the outer product <i>p</i><sub>2</sub><i>p</i><sub>1</sub><sup>⊤</sup>. The last right singular vector minimizes the algebraic residual subject to a unit coefficient norm. After reshaping it into a 3 × 3 matrix, a second SVD sets the smallest singular value to zero and reconstructs a rank-two estimate.</p>
  <p>The normalized version first centers each point set and rescales it so the mean distance from the origin is √2. It applies the same rank-two fit in normalized coordinates and returns <i>F</i> = <i>T</i><sub>2</sub><sup>⊤</sup><i>F̃T</i><sub>1</sub>. Centering and scaling keep the coordinate products and constants in the design matrix on comparable scales.</p>
  <div class="matrix-grid">{''.join(matrices)}</div>
  <p class="caption">Each matrix has unit Frobenius norm. Its largest-magnitude entry is positive to fix the arbitrary projective sign. Nine decimal places preserve the small coefficients.</p>
  <h3>Mean point-to-line distance</h3>
  <p>For each match, form the line <i>ℓ</i> = <i>F</i><sup>⊤</sup><i>p</i><sub>2</sub> = (<i>a</i>, <i>b</i>, <i>c</i>)<sup>⊤</sup> in Image 1. For a pixel (<i>x</i>, <i>y</i>), the perpendicular distance is |<i>ax</i> + <i>by</i> + <i>c</i>| / √(<i>a</i>² + <i>b</i>²). Average over all matches, then swap views and transpose <i>F</i> for Image 2. The distance is invariant to the scale of <i>F</i>.</p>
  {table(("Pair", "Matches", "Estimator", "Image 1 (px)", "Image 2 (px)"), p1_rows)}
  <p>Normalization reduced the mean distance from 9.70–28.03 px to 0.83–0.89 px across the four comparisons. These are residuals on the matched points used for the fit.</p>
</section>

<section class="report-section" id="epipolar-overlays">
  {section_title("1(e–f)", "Epipolar lines on both pairs")}
  <p>Within each figure, a colored dot represents an observed image point. The same-color line is predicted from its partner in the other image. The overlays show ten matches per pair for legibility. The reported distances use every match.</p>
  <div class="gallery">{pair_1}{pair_2}</div>
</section>

<section class="report-section" id="rectification">
  {section_title("2(a–d)", "Matching homographies and rectification")}
  <p>The epipoles satisfy <i>Fe</i><sub>1</sub> = 0 and <i>F</i><sup>⊤</sup><i>e</i><sub>2</sub> = 0. I obtained them from the null spaces of the normalized Set 1 fit. The computed homogeneous coordinates are {epipoles}, respectively.</p>
  <p>To construct <i>H</i><sub>2</sub>, translate the center of Image 2 to the origin, rotate its epipole onto the horizontal axis, and use the projective term to send it to infinity before undoing the translation. The first homography uses <i>H</i><sub>1</sub> = <i>H</i><sub>A</sub><i>H</i><sub>2</sub><i>M</i>, with <i>M</i> = [<i>e</i><sub>2</sub>]<sub>×</sub><i>F</i> + <i>e</i><sub>2</sub>[1 1 1]. A least-squares fit chooses the first row of <i>H</i><sub>A</sub> to reduce squared horizontal displacement. Its remaining rows keep vertical coordinates fixed. Both homographies send their epipoles to the horizontal point at infinity. I resampled the images by inverse warping with bilinear interpolation.</p>
  {rectified}
  {table(("Absolute vertical mismatch", "Original (px)", "Rectified (px)"), rect_rows)}
  <div class="callout"><p><strong>Why matching gets easier.</strong> A point now predicts an approximately horizontal scanline in the other image. Matching can search along that row, or a narrow band around it to allow for error, and measure the remaining displacement as horizontal disparity.</p></div>
</section>

<section class="report-section" id="factorization">
  {section_title("3(a–f)", "Affine structure from motion")}
  <p>Stack the two views into four rows (<i>x</i><sub>1</sub>, <i>y</i><sub>1</sub>, <i>x</i><sub>2</sub>, <i>y</i><sub>2</sub>). Subtract each row mean to remove the image translations. The centered measurement matrix <i>W</i> factors into motion and structure by retaining its first three singular components.</p>
  <pre class="formula">W ≈ M S     M = U₃ Σ₃¹ᐟ²     S = Σ₃¹ᐟ² V₃ᵀ</pre>
  {table(("Correspondences", "Points", "σ₁", "σ₂", "σ₃", "σ₄", "σ₄ / σ₃"), factor_rows)}
  <p>In the ideal noiseless affine model, <i>M</i> is 4 × 3 and <i>S</i> is 3 × <i>N</i>, so <i>W</i> has at most three nonzero singular values. Three are expected when the scene and camera motion support three structure dimensions. An exactly planar scene can have rank two. Perspective effects and imperfect image measurements explain why the observed matrices have four nonzero values.</p>
  <h3>Full set vs. supplied subset</h3>
  <p>The full set recovers the broad layout of the reference. Centering, rotation and scale change the appearance of raw 3D coordinates without changing the shape. More generally the uncalibrated affine factors have a gauge: for any invertible <i>A</i>, replacing <i>M</i> with <i>MA</i> and <i>S</i> with <i>A</i><sup>−1</sup><i>S</i> gives the same image measurements. I fit one 3D rotation and uniform scale to each centered reconstruction for display. The residual is {full["similarity_relative_rms"]:.1%} of the centered ground-truth RMS for the full set and {subset["similarity_relative_rms"]:.1%} for the subset.</p>
  {full_factorization}
  {subset_factorization}
  <p>The subset covers an almost planar portion of the scene. Its ground-truth third-to-first singular-value ratio falls from {full["truth_thickness_ratio"]:.3f} to {subset["truth_thickness_ratio"]:.3f}. In image space, σ₃ falls sharply and σ₄ approaches it. The two dominant modes still describe the arrangement within the plane, but the data give the third mode little separation from the discarded fourth mode. The resulting depth errors are clearest in the side profiles.</p>
</section>

<section class="report-section" id="triangulation">
  {section_title("4(a–e)", "Projective triangulation")}
  <h3>Relative pose from the essential matrix</h3>
  <p>Compute <i>E</i> = <i>K</i><sup>⊤</sup><i>FK</i> and take its SVD <i>UΣV</i><sup>⊤</sup>. The two candidate rotations come from <i>UWV</i><sup>⊤</sup> and <i>UW</i><sup>⊤</sup><i>V</i><sup>⊤</sup>, where <i>W</i> is a 90° rotation about the third axis. Multiplying each candidate by its determinant makes it a proper rotation. Pair each rotation with both signs of the third column of <i>U</i> to get four candidate poses. Translation magnitude is fixed to one because <i>E</i> determines its direction up to scale.</p>
  <h3>Linear initialization and reprojection refinement</h3>
  <p>For each camera <i>P</i><sub>i</sub> and observation (<i>x</i>, <i>y</i>), form the rows <i>xP</i><sub>i,3</sub> − <i>P</i><sub>i,1</sub> and <i>yP</i><sub>i,3</sub> − <i>P</i><sub>i,2</sub>. The last right singular vector of the stacked system gives a homogeneous 3D point. Divide by its fourth component to initialize the nonlinear estimate.</p>
  <p>With <i>q</i> = <i>P</i><sub>i</sub>[<i>X</i> 1]<sup>⊤</sup>, the residual is the predicted pixel (<i>q</i><sub>1</sub>/<i>q</i><sub>3</sub>, <i>q</i><sub>2</sub>/<i>q</i><sub>3</sub>) minus the measured pixel. The quotient rule gives each Jacobian row.</p>
  <pre class="formula">Jᵢ,ⱼ = (Pᵢ,ⱼ,1:3 − (qⱼ / q₃) Pᵢ,₃,1:3) / q₃   for j = 1, 2
X ← X − J⁺e   for ten Gauss–Newton iterations</pre>
  <p>Here 1:3 denotes the first three columns and <i>J</i><sup>+</sup> is the pseudoinverse of the stacked Jacobian. On the supplied four-view test case, the stacked reprojection residual norm decreased from {dlt:.4f} px to {refined:.4f} px. The analytic Jacobian agreed with a central finite difference to {p4["jacobian_fd_max_abs"]:.2e} maximum absolute error.</p>
  <h3>Cheirality selects the camera pose</h3>
  <p>For each candidate, triangulate the matches using <i>K</i>[<i>I</i> | 0] and <i>K</i>[<i>R</i> | <i>t</i>]. Count points with positive depth in both cameras by checking <i>X</i><sub>z</sub> and (<i>RX</i> + <i>t</i>)<sub>z</sub>. For B21–B22 only one candidate puts any supplied point in front of both cameras. Its entries agree with the starter’s pose reference within {p4["max_candidate_reference_difference"]:.2e}.</p>
  <div class="matrix-grid">{matrix("Selected [R | t] · B21–B22", p4["RT"], 6)}{vote_table}</div>
</section>

<section class="report-section" id="statue">
  {section_title("4(f)", "Statue reconstruction")}
  {sources}
  <p>With a focal length of {p4["focal_length"]:.4f} px and image-centered coordinates, the supplied frame-merging and bundle-adjustment routines registered five camera poses and retained {p4["merged_sparse_tracks"]} sparse tracks. I retained the starter’s dense plotting range, which triangulates B21–B22, B22–B23 and B23–B24 and yields {p4["finite"]:,} finite points. The frontal view recovers the head and pedestal, while the oblique view shows the depth and incomplete surface coverage.</p>
  {cloud}
  <h3>Why a house is harder</h3>
  <p>A larger structure needs more views and enough overlap to link them. Windows and facade patterns can create ambiguous matches, textureless walls give few reliable points, and corners or vegetation can occlude surfaces. With approximate rectified depth <i>Z</i> = <i>fB</i>/<i>d</i>, the same disparity error causes larger depth error at greater distance. Small nearby baselines give weak depth, while large viewpoint changes can break correspondences. Longer chains also allow pose and scale error to accumulate unless additional widely separated views constrain the reconstruction.</p>
  <h3>Reproduce the report</h3>
  <pre class="command">python -m pip install -r requirements.txt
python generate_results.py
python build_report.py</pre>
  <p>The four submitted modules retain the starter function names. The result generator checks exact synthetic stereo and affine cases, numerical rank, epipole mapping, the Jacobian and the supplied reference pose. The code package includes the source data and the full-precision measurements used here.</p>
  <div class="downloads"><a href="downloads/{CODE}">Code ZIP</a><a href="downloads/measurements.json">Measurements</a><a href="downloads/statue-points.npz">Triangulated points</a><a href="images/rectified-1.png">Rectified Image 1</a><a href="images/rectified-2.png">Rectified Image 2</a></div>
  <h3>References</h3>
  <ol class="references">
    <li>University of Waterloo, SYDE 671 Assignment 4, Fall 2026. Handout, Python starter and data. Adapted from Stanford CS231A.</li>
    <li>Stanford University, CS231A, <a href="https://web.stanford.edu/class/cs231a/hw_2025_spring/ps2.pdf">Problem Set 2</a>, Spring 2025.</li>
    <li>R. Hartley and A. Zisserman, <a href="https://www.robots.ox.ac.uk/~vgg/hzbook/">Multiple View Geometry in Computer Vision</a>, second edition, Cambridge University Press, 2004, chapters 9–12.</li>
    <li>C. Tomasi and T. Kanade, <a href="https://doi.org/10.1007/BF00129684">Shape and Motion from Image Streams under Orthography: A Factorization Method</a>, IJCV 9, 137–154, 1992.</li>
  </ol>
</section>
</main>
<footer><span>SYDE 671 · Assignment 4</span><span>Moksh Trehan · 2026</span></footer>
<dialog id="image-dialog" aria-label="Enlarged figure">
  <div class="dialog-toolbar"><span id="dialog-caption"></span><a id="dialog-original" href="#overview">Open original</a><button id="dialog-close" type="button">Close</button></div>
  <img id="dialog-image" alt="">
</dialog>
</body>
</html>
'''


def main():
    data = json.loads((ROOT / "results" / "measurements.json").read_text())
    (SITE / "index.html").write_text(make_report(data), encoding="utf-8")
    downloads = SITE / "downloads"
    downloads.mkdir(exist_ok=True)
    for file in ("measurements.json", "statue-points.npz"):
        shutil.copyfile(ROOT / "results" / file, downloads / file)


if __name__ == "__main__":
    main()
