# SYDE 671 Assignment 4 · Two-view geometry

Moksh Trehan · Fall 2026

## Run the code

Create a Python environment and install the dependencies:

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python generate_results.py
python build_report.py
```

Run each problem script directly to reproduce the starter's checks and plots:

```sh
python p1.py
python p2.py
python p3.py
python p4.py
```

The results script runs the real-data experiments and synthetic checks without opening windows. It produces the figures in `site/images/`, the full-precision values in `results/measurements.json`, and the dense statue points in `results/statue-points.npz`. The final statue plot uses the three dense pairs selected by the starter script. All four adjacent pairs contribute to estimating the five camera poses.

The coursework's 2D text data store row then column. `get_data_from_txt_file` returns pixel x then y. The statue's supplied correspondences already use image-centered coordinates. The code reads the original trusted legacy NumPy object-array files for the statue with Python 2 encoding compatibility.

Open `site/index.html` for the offline report. To rebuild the PDF, install ReportLab in the same environment and run `python export_pdf.py`. Run `python package_submission.py` to refresh both ZIPs and the site download links after rebuilding the report.

The starting modules, datasets, and statue image attribution are supplied by the course. The separate notebook in the original starter ZIP is an optional interface to those same starter scripts and is not needed to run this project.
