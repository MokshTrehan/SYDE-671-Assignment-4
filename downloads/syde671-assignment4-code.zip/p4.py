import sys
import numpy as np
import os
import matplotlib.pyplot as plt
from epipolar_utils import imread


def _linear_points(image_points, cameras):
    """Triangulate one track or a batch of tracks from common cameras."""
    observations = np.asarray(image_points, dtype=float)
    cameras = np.asarray(cameras, dtype=float)
    equations = observations[..., :, :, None] * cameras[:, None, 2, :] - cameras[:, :2, :]
    equations = equations.reshape(observations.shape[:-2] + (-1, 4))
    _, _, vh = np.linalg.svd(equations, full_matrices=False)
    solution = vh[..., -1, :]
    with np.errstate(divide="ignore", invalid="ignore"):
        return solution[..., :3] / solution[..., 3, None]


def _project_with_jacobian(points, cameras):
    cameras = np.asarray(cameras, dtype=float)
    projected = np.einsum("mij,...j->...mi", cameras[:, :, :3], points) + cameras[:, :, 3]
    depth = projected[..., 2:3]
    with np.errstate(divide="ignore", invalid="ignore"):
        uv = projected[..., :2] / depth
        derivative = (cameras[:, :2, :3] - uv[..., None] * cameras[:, None, 2, :3])
        derivative = derivative / depth[..., None]
    return uv, derivative


def nonlinear_points(observations, cameras):
    """Apply the same ten Gauss-Newton steps to every finite DLT track."""
    points = _linear_points(observations, cameras)
    for _ in range(10):
        projected, jacobians = _project_with_jacobian(points, cameras)
        residuals = (projected - observations).reshape(len(points), -1)
        jacobians = jacobians.reshape(len(points), -1, 3)
        valid = np.isfinite(residuals).all(axis=1) & np.isfinite(jacobians).all(axis=(1, 2))
        steps = np.linalg.pinv(jacobians[valid]) @ residuals[valid, :, None]
        points[valid] -= steps[..., 0]
    return points


'''
ESTIMATE_INITIAL_RT from the Essential Matrix, we can compute 4 initial
guesses of the relative RT between the two cameras
Arguments:
    E - the Essential Matrix between the two cameras
Returns:
    RT: A 4x3x4 tensor in which the 3x4 matrix RT[i,:,:] is one of the
        four possible transformations
'''
def estimate_initial_RT(E):
    u, _, vh = np.linalg.svd(E)
    w = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]])
    rotations = (u @ w @ vh, u @ w.T @ vh)
    return np.stack([np.column_stack((np.linalg.det(q) * q, sign * u[:, 2]))
                     for q in rotations for sign in (1, -1)])

'''
LINEAR_ESTIMATE_3D_POINT given a corresponding points in different images,
compute the 3D point is the best linear estimate
Arguments:
    image_points - the measured points in each of the M images (Mx2 matrix)
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    point_3d - the 3D point
'''
def linear_estimate_3d_point(image_points, camera_matrices):
    return _linear_points(np.asarray(image_points, dtype=float), camera_matrices)

'''
REPROJECTION_ERROR given a 3D point and its corresponding points in the image
planes, compute the reprojection error vector and associated Jacobian
Arguments:
    point_3d - the 3D point corresponding to points in the image
    image_points - the measured points in each of the M images (Mx2 matrix)
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    error - the 2Mx1 reprojection error vector
'''
def reprojection_error(point_3d, image_points, camera_matrices):
    predictions, _ = _project_with_jacobian(np.asarray(point_3d), camera_matrices)
    return (predictions - image_points).reshape(-1)

'''
JACOBIAN given a 3D point and its corresponding points in the image
planes, compute the reprojection error vector and associated Jacobian
Arguments:
    point_3d - the 3D point corresponding to points in the image
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    jacobian - the 2Mx3 Jacobian matrix
'''
def jacobian(point_3d, camera_matrices):
    _, derivatives = _project_with_jacobian(np.asarray(point_3d), camera_matrices)
    return derivatives.reshape(-1, 3)

'''
NONLINEAR_ESTIMATE_3D_POINT given a corresponding points in different images,
compute the 3D point that iteratively updates the points
Arguments:
    image_points - the measured points in each of the M images (Mx2 matrix)
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    point_3d - the 3D point
'''
def nonlinear_estimate_3d_point(image_points, camera_matrices):
    return nonlinear_points(np.asarray(image_points, dtype=float)[None], camera_matrices)[0]

'''
ESTIMATE_RT_FROM_E from the Essential Matrix, we can compute  the relative RT 
between the two cameras
Arguments:
    E - the Essential Matrix between the two cameras
    image_points - N measured points in each of the M images (NxMx2 matrix)
    K - the intrinsic camera matrix
Returns:
    RT: The 3x4 matrix which gives the rotation and translation between the 
        two cameras
'''
def estimate_RT_from_E(E, image_points, K):
    candidates, votes = pose_cheirality_votes(E, image_points, K)
    return candidates[np.argmax(votes)]


def pose_cheirality_votes(E, image_points, K):
    camera1 = K @ np.column_stack((np.eye(3), np.zeros(3)))
    candidates = estimate_initial_RT(E)
    votes = []
    for candidate in candidates:
        cameras = np.stack((camera1, K @ candidate))
        points = _linear_points(image_points, cameras)
        second_depth = points @ candidate[2, :3] + candidate[2, 3]
        votes.append(np.count_nonzero((points[:, 2] > 0) & (second_depth > 0)))
    return candidates, np.asarray(votes)


def reconstruct_statue(matches_subset, dense_matches, fundamental_matrices,
                       focal_length, image_width, image_height):
    """Run the supplied frame-merging pipeline and its dense reconstruction loop."""
    from sfm_utils import Frame, bundle_adjustment, merge_all_frames

    frames = []
    for matches, matrix in zip(matches_subset, fundamental_matrices):
        frame = Frame(matches.T, focal_length, matrix, image_width, image_height)
        bundle_adjustment(frame)
        frames.append(frame)
    merged = merge_all_frames(frames)

    # Preserve the dense-pair range of the course starter's final plot.
    cameras = merged.K @ merged.motion
    clouds = []
    for i in range(len(frames) - 1):
        observations = dense_matches[i].T.reshape(-1, 2, 2)
        clouds.append(nonlinear_points(observations, cameras[i:i + 2]))
    return merged, clouds


if __name__ == '__main__':
    run_pipeline = True

    # Load the data
    image_data_dir = 'data/statue/'
    unit_test_camera_matrix = np.load('data/unit_test_camera_matrix.npy')
    unit_test_image_matches = np.load('data/unit_test_image_matches.npy')
    image_paths = [os.path.join(image_data_dir, 'images', x) for x in
        sorted(os.listdir('data/statue/images')) if '.jpg' in x]
    focal_length = 719.5459
    matches_subset = np.load(os.path.join(image_data_dir,
        'matches_subset.npy'), allow_pickle=True, encoding='latin1')[0,:]
    dense_matches = np.load(os.path.join(image_data_dir, 'dense_matches.npy'), 
                               allow_pickle=True, encoding='latin1')
    fundamental_matrices = np.load(os.path.join(image_data_dir,
        'fundamental_matrices.npy'), allow_pickle=True, encoding='latin1')[0,:]

    # Part A: Computing the 4 initial R,T transformations from Essential Matrix
    print('-' * 80)
    print("Part A: Check your matrices against the example R,T")
    print('-' * 80)
    K = np.eye(3)
    K[0,0] = K[1,1] = focal_length
    E = K.T.dot(fundamental_matrices[0]).dot(K)
    im0 = imread(image_paths[0])
    im_height, im_width, _ = im0.shape
    example_RT = np.array([[0.9736, -0.0988, -0.2056, 0.9994],
        [0.1019, 0.9948, 0.0045, -0.0089],
        [0.2041, -0.0254, 0.9786, 0.0331]])
    print("Example RT:\n", example_RT)
    estimated_RT = estimate_initial_RT(E)
    print('')
    print("Estimated RT:\n", estimated_RT)

    # Part B: Determining the best linear estimate of a 3D point
    print('-' * 80)
    print('Part B: Check that the difference from expected point ')
    print('is near zero')
    print('-' * 80)
    camera_matrices = np.zeros((2, 3, 4))
    camera_matrices[0, :, :] = K.dot(np.hstack((np.eye(3), np.zeros((3,1)))))
    camera_matrices[1, :, :] = K.dot(example_RT)
    unit_test_matches = matches_subset[0][:,0].reshape(2,2)
    estimated_3d_point = linear_estimate_3d_point(unit_test_matches.copy(),
        camera_matrices.copy())
    expected_3d_point = np.array([0.6774, -1.1029, 4.6621])
    print("Difference: ", np.fabs(estimated_3d_point - expected_3d_point).sum())

    # Part C: Calculating the reprojection error and its Jacobian
    print('-' * 80)
    print('Part C: Check that the difference from expected error/Jacobian ')
    print('is near zero')
    print('-' * 80)
    estimated_error = reprojection_error(
            expected_3d_point, unit_test_matches, camera_matrices)
    estimated_jacobian = jacobian(expected_3d_point, camera_matrices)
    expected_error = np.array((-0.0095458, -0.5171407,  0.0059307,  0.501631))
    print("Error Difference: ", np.fabs(estimated_error - expected_error).sum())
    expected_jacobian = np.array([[ 154.33943931, 0., -22.42541691],
         [0., 154.33943931, 36.51165089],
         [141.87950588, -14.27738422, -56.20341644],
         [21.9792766, 149.50628901, 32.23425643]])
    print("Jacobian Difference: ", np.fabs(estimated_jacobian
        - expected_jacobian).sum())

    # Part D: Determining the best nonlinear estimate of a 3D point
    print('-' * 80)
    print('Part D: Check that the reprojection error from nonlinear method')
    print('is lower than linear method')
    print('-' * 80)
    estimated_3d_point_linear = linear_estimate_3d_point(
        unit_test_image_matches.copy(), unit_test_camera_matrix.copy())
    estimated_3d_point_nonlinear = nonlinear_estimate_3d_point(
        unit_test_image_matches.copy(), unit_test_camera_matrix.copy())
    error_linear = reprojection_error(
        estimated_3d_point_linear, unit_test_image_matches,
        unit_test_camera_matrix)
    print("Linear method error:", np.linalg.norm(error_linear))
    error_nonlinear = reprojection_error(
        estimated_3d_point_nonlinear, unit_test_image_matches,
        unit_test_camera_matrix)
    print("Nonlinear method error:", np.linalg.norm(error_nonlinear))

    # Part E: Determining the correct R, T from Essential Matrix
    print('-' * 80)
    print("Part E: Check your matrix against the example R,T")
    print('-' * 80)
    estimated_RT = estimate_RT_from_E(E,
        np.expand_dims(unit_test_image_matches[:2,:], axis=0), K)
    print("Example RT:\n", example_RT)
    print('')
    print("Estimated RT:\n", estimated_RT)

    # Part F: Run the entire Structure from Motion pipeline
    if not run_pipeline:
        sys.exit()
    print('-' * 80)
    print('Part F: Run the entire SFM pipeline')
    print('-' * 80)
    merged_frame, clouds = reconstruct_statue(
        matches_subset, dense_matches, fundamental_matrices,
        focal_length, im_width, im_height)
    dense_structure = np.concatenate(clouds)

    fig = plt.figure(figsize=(10,10))
    ax = fig.add_subplot(projection='3d')
    ax.scatter(dense_structure[:,0], dense_structure[:,1], dense_structure[:,2],
        c='k', depthshade=True, s=2)
    ax.set_xlim(-5, 5)
    ax.set_ylim(-5, 5)
    ax.set_zlim(0, 10)
    ax.view_init(-100, 90)

    plt.show()
