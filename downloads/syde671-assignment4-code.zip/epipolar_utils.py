import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from scipy.ndimage import map_coordinates


def imread(path):
    with Image.open(path) as image:
        return np.array(image)

'''
GET_DATA_FROM_TXT_FILE 
Arguments:
    filename - a path (str) to the data location
Returns:
    points - a matrix of points where each row is either: 
        a) the homogenous coordinates (x,y,1) if the data is 2D
        b) the coordinates (x,y,z) if the data is 3D
    use_subset - use a predefined subset (this is hard coded for now)
'''
def get_data_from_txt_file(filename, use_subset = False):
    with open(filename) as f:
            lines = f.read().splitlines() 
    number_pts = int(lines[0])

    points = np.ones((number_pts, 3))
    for i in range(number_pts):
        split_arr = lines[i+1].split()
        if len(split_arr) == 2:
            y, x = split_arr
        else:
            x, y, z = split_arr
            points[i,2] = z
        points[i,0] = x 
        points[i,1] = y
    return points

'''
COMPUTE_RECTIFIED_IMAGE
Arguments:
    im - an image
    H - a homography matrix that rectifies the image
Returns:
    new_image - a new image matrix after applying the homography
    offset - the offest in the image.
'''
def compute_rectified_image(im, H):
    height, width = im.shape[:2]
    corners = np.array([[0, 0, 1], [width - 1, 0, 1],
                        [0, height - 1, 1], [width - 1, height - 1, 1]])
    bounds = corners @ H.T
    if bounds[:, 2].min() <= 0 <= bounds[:, 2].max():
        raise ValueError("The rectified image is unbounded")
    bounds = bounds[:, :2] / bounds[:, 2, None]
    lower = np.floor(bounds.min(axis=0)).astype(int)
    upper = np.ceil(bounds.max(axis=0)).astype(int)
    x, y = np.meshgrid(np.arange(lower[0], upper[0] + 1),
                       np.arange(lower[1], upper[1] + 1))
    grid = np.stack((x, y, np.ones_like(x)), axis=-1)
    source = grid @ np.linalg.inv(H).T
    with np.errstate(divide="ignore", invalid="ignore"):
        coordinates = (source[..., :2] / source[..., 2, None])[..., ::-1]
    coordinates = np.where(np.isfinite(coordinates), coordinates, -1)
    coordinates = np.moveaxis(coordinates, -1, 0)
    if im.ndim == 2:
        result = map_coordinates(im, coordinates, order=1, mode="constant", cval=0)
    else:
        result = np.stack([map_coordinates(channel, coordinates, order=1,
                                          mode="constant", cval=0)
                           for channel in np.moveaxis(im, -1, 0)], axis=-1)
    return result, tuple(lower)

'''
SCATTER_3D_AXIS_EQUAL
Arguments:
    X - the coordinates on the x axis (N long vector)
    Y - the coordinates on the y axis (N long vector)
    Z - the coordinates on the z axis (N long vector)
    ax - the pyplot axis
Returns:
    Nothing; instead plots the points of (X, Y, Z) such that the axes are equal
'''
def scatter_3D_axis_equal(X, Y, Z, ax):
    ax.scatter(X, Y, Z)
    max_range = np.array([X.max()-X.min(), Y.max()-Y.min(), Z.max()-Z.min()]).max() / 2.0

    mid_x = (X.max()+X.min()) * 0.5
    mid_y = (Y.max()+Y.min()) * 0.5
    mid_z = (Z.max()+Z.min()) * 0.5
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)
