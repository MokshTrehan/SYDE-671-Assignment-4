"""Render the same content as the offline website to a letter-sized hand-in PDF."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

import matplotlib
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph,
                                Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle)

from build_report import PDF, ROOT, SITE

INK = colors.HexColor("#182b42")
MUTED = colors.HexColor("#536479")
BLUE = colors.HexColor("#174dab")
LINE = colors.HexColor("#d6dfeb")
PALE = colors.HexColor("#f1f5fa")
SYSTEM_FONTS = Path("/System/Library/Fonts/Supplemental")
MPL_FONTS = Path(matplotlib.get_data_path()) / "fonts" / "ttf"
OUTPUT = ROOT / "output" / "pdf" / PDF
MARGIN = 46
WIDTH = letter[0] - 2*MARGIN - 12


def register_fonts():
    if (SYSTEM_FONTS / "Georgia.ttf").exists():
        serif = [SYSTEM_FONTS / f"Georgia{variant}.ttf" for variant in ("", " Italic")]
    else:
        serif = [MPL_FONTS / f"DejaVuSerif{variant}.ttf" for variant in ("", "-Italic")]
    files = {
        "Display": serif[0], "DisplayItalic": serif[1],
        "Body": MPL_FONTS / "DejaVuSans.ttf",
        "BodyBold": MPL_FONTS / "DejaVuSans-Bold.ttf",
        "BodyItalic": MPL_FONTS / "DejaVuSans-Oblique.ttf",
        "BodyBoldItalic": MPL_FONTS / "DejaVuSans-BoldOblique.ttf",
        "Mono": MPL_FONTS / "DejaVuSansMono.ttf",
    }
    for key, path in files.items():
        pdfmetrics.registerFont(TTFont(key, str(path)))
    pdfmetrics.registerFontFamily("Body", normal="Body", bold="BodyBold", italic="BodyItalic",
                                  boldItalic="BodyBoldItalic")
    pdfmetrics.registerFontFamily("Display", normal="Display", italic="DisplayItalic")


def style(name, font="Body", size=9.25, leading=13.2, before=0, after=8, color=INK, **kwargs):
    return ParagraphStyle(name, fontName=font, fontSize=size, leading=leading, textColor=color,
                          spaceBefore=before, spaceAfter=after, alignment=TA_LEFT, **kwargs)


STYLES = {
    "p": style("body"),
    "caption": style("caption", size=8.15, leading=11, color=MUTED, after=9),
    "eyebrow": style("eyebrow", "BodyBold", 9, 12, after=10, color=BLUE),
    "byline": style("byline", size=10, leading=14, color=MUTED, after=15),
    "lede": style("lede", size=14, leading=19, color=MUTED, after=14),
    "h1": style("title", "Display", 49, 52, before=10, after=13),
    "h2": style("section", "Display", 28, 31, after=15),
    "h3": style("subheading", "BodyBold", 10.7, 14, before=4, after=5, keepWithNext=True),
    "matrix": style("matrix heading", "BodyBold", 8.1, 10, after=3),
    "pre": style("code", "Mono", 8.2, 11.2, after=0),
    "cell": style("cell", size=8.2, leading=11, after=0),
    "header": style("table header", "BodyBold", 8.2, 11, color=colors.white, after=0),
    "stat": style("number", "BodyBold", 16.5, 20, after=4),
    "stat_caption": style("number caption", size=8.2, leading=11, color=MUTED, after=0),
    "contents": style("contents", size=9.2, leading=13, color=BLUE, after=3),
    "reference": style("reference", size=7.9, leading=11, color=MUTED, leftIndent=11, firstLineIndent=-11, after=3),
}


def element_text(node):
    return "".join(node.itertext())


def rich(node):
    serialized = ET.tostring(node, encoding="unicode")
    content = serialized[serialized.index(">")+1:serialized.rindex(f"</{node.tag}>")]
    content = re.sub(r'<span[^>]*class="fig-number"[^>]*>(.*?)</span>', r"<b>\1</b>", content)
    content = content.replace("<strong>", "<b>").replace("</strong>", "</b>")
    content = content.replace("<em>", '<font color="#174dab"><i>').replace("</em>", "</i></font>")
    content = content.replace("⊤", "T").replace("<br />", "<br/>")
    return content


def paragraph(node, role=None):
    return Paragraph(rich(node), STYLES[role or node.get("class", "p")])


def image_flow(node, width, max_height):
    path = SITE / node.find(".//img").attrib["src"]
    with PILImage.open(path) as im:
        w, h = im.size
    scale = min(width/w, max_height/h)
    figure = Image(str(path), width=w*scale, height=h*scale)
    return [figure, Spacer(1, 4), paragraph(node.find("figcaption"), "caption")]


def table_format(data, widths=None, header=True):
    result = Table(data, colWidths=widths, hAlign="LEFT", repeatRows=int(header))
    commands = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
    ]
    if header:
        commands.extend([
            ("BACKGROUND", (0, 0), (-1, 0), INK),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PALE]),
            ("LINEBELOW", (0, 1), (-1, -1), .35, LINE),
        ])
    result.setStyle(TableStyle(commands))
    return result


def data_table(node, width, widths=None):
    rows = []
    for row in node.findall(".//tr"):
        rows.append([paragraph(cell, "header" if cell.tag == "th" else "cell") for cell in row])
    return table_format(rows, widths or [width/len(rows[0])]*len(rows[0]))


def panel(items, width, line_color=LINE):
    result = table_format([[items]], [width], header=False)
    result.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, 0), PALE),
                               ("LINEBEFORE", (0, 0), (0, 0), 1.5, line_color)]))
    return result


def code_panel(node):
    content = element_text(node).replace("ᵀ", "^T").replace("⁺", "^+")
    if "W ≈" in content:
        content = "W ≈ M S      M = U3 sqrt(Σ3)      S = sqrt(Σ3) V3^T"
    elif content.startswith("J"):
        content = ("J[i,j] = (P[i,j,1:3] − (q[j] / q[3]) P[i,3,1:3]) / q[3],  j = 1, 2\n"
                   "X ← X − J^+ e   for ten Gauss–Newton iterations")
    return panel([Preformatted(content, STYLES["pre"])], WIDTH, BLUE)


def matrix_panel(node, width):
    return panel([paragraph(node.find("h3"), "matrix"),
                  Preformatted(element_text(node.find("pre")), STYLES["pre"])], width)


def two_col(left, right):
    return table_format([[left, "", right]], [(WIDTH-12)/2, 12, (WIDTH-12)/2], header=False)


def heading(target):
    label = target.find("span")
    title = target.find("h2")
    return [paragraph(label, "eyebrow"), paragraph(title, "h2")]


def cover(section):
    lead = section.find("div/div")
    story = [paragraph(node, node.tag if node.tag == "h1" else None) for node in lead]
    stats = []
    for item in section.find("div[@class='stats']"):
        stats.append([paragraph(item.find("strong"), "stat"),
                      paragraph(item.find("span"), "stat_caption")])
    strip = table_format([stats], [WIDTH/3]*3, header=False)
    strip.setStyle(TableStyle([("LINEABOVE", (0, 0), (-1, 0), .6, LINE),
                               ("LINEBELOW", (0, 0), (-1, 0), .6, LINE),
                               ("TOPPADDING", (0, 0), (-1, 0), 10),
                               ("BOTTOMPADDING", (0, 0), (-1, 0), 10)]))
    story.extend([strip, Spacer(1, 12), paragraph(section.find("p")), Spacer(1, 12)])
    story.append(Paragraph("Contents", STYLES["h3"]))
    for link in section.find("div[@class='contents']"):
        story.append(paragraph(link, "contents"))
    story.append(Spacer(1, 11))
    figure = ET.fromstring('<figure><a><img src="images/statue-reconstruction.jpg" /></a>'
                           '<figcaption>Frontal and oblique views of the statue reconstruction.</figcaption></figure>')
    story.extend(image_flow(figure, WIDTH, 133))
    return story


def report_pages(main):
    story = []
    for section in main:
        name = section.get("id")
        if name == "overview":
            story.extend(cover(section))
            continue
        story.append(PageBreak())
        for node in section:
            if name == "factorization" and node.tag == "figure" and node.find(".//img").get("src").endswith("set1-factorization.png"):
                story.append(PageBreak())
                story.append(Paragraph("3(c–f)", STYLES["eyebrow"]))
                story.append(Paragraph("Factorization versus ground truth", STYLES["h2"]))
            if name == "statue" and node.tag == "h3" and node.text == "Reproduce the report":
                story.append(PageBreak())
                story.append(Paragraph("Reproducibility", STYLES["eyebrow"]))
                story.append(paragraph(node, "h2"))
                continue
            kind = node.get("class", "")
            if kind == "downloads":
                continue
            if kind == "section-title":
                story.extend(heading(node))
            elif node.tag in ("p", "h3"):
                story.append(paragraph(node, "h3" if node.tag == "h3" else None))
            elif kind == "matrix-grid":
                groups = []
                for child in node:
                    w = (WIDTH-12)/2 - 14
                    if child.get("class") == "matrix":
                        groups.append(matrix_panel(child, w))
                    else:
                        groups.append(data_table(child, w, [w*.50, w*.50]))
                for i in range(0, len(groups), 2):
                    story.append(two_col(*groups[i:i+2]))
                story.append(Spacer(1, 3))
            elif kind == "gallery":
                story.append(two_col(*(image_flow(fig, (WIDTH-12)/2-14, 290) for fig in node)))
            elif node.tag == "figure":
                max_height = {"rectification": 222, "factorization": 165, "statue": 225}[name]
                if node.find(".//img").get("src").endswith("statue-sources.jpg"):
                    max_height = 64
                story.append(KeepTogether(image_flow(node, WIDTH, max_height)))
            elif kind == "table-scroll":
                fractions = {
                    "factorization": [.22, .09, .14, .14, .14, .14, .13],
                    "fundamental": [.15, .14, .29, .21, .21],
                    "rectification": [.48, .26, .26],
                }
                widths = [WIDTH*f for f in fractions[name]]
                story.extend([data_table(node, WIDTH, widths), Spacer(1, 7)])
            elif kind in ("formula", "command"):
                story.extend([code_panel(node), Spacer(1, 7)])
            elif kind == "callout":
                story.append(panel([paragraph(node.find("p"))], WIDTH, BLUE))
            elif kind == "references":
                for index, item in enumerate(node, 1):
                    story.append(Paragraph(f"{index}. {rich(item)}", STYLES["reference"]))
            else:
                raise ValueError(f"Unrecognized section content: {name} {kind} {node.tag}")
    return story


def footer(canvas, document):
    y = 33
    canvas.setStrokeColor(LINE)
    canvas.setLineWidth(.5)
    canvas.line(MARGIN, y+10, letter[0]-MARGIN, y+10)
    canvas.setFillColor(MUTED)
    canvas.setFont("Body", 7.7)
    canvas.drawString(MARGIN, y-2, "SYDE 671 · Assignment 4 · Moksh Trehan")
    canvas.drawRightString(letter[0]-MARGIN, y-2, str(document.page))


def main():
    register_fonts()
    text = (SITE / "index.html").read_text()
    fragment = text[text.index("<main>"):text.index("</main>")+len("</main>")]
    fragment = re.sub(r"<(img|br)([^>]*)>", r"<\1\2 />", fragment)
    tree = ET.fromstring(fragment)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(OUTPUT), pagesize=letter, leftMargin=MARGIN, rightMargin=MARGIN,
                            topMargin=44, bottomMargin=54, title="SYDE 671 Assignment 4 - Two-view geometry",
                            author="Moksh Trehan", subject="Advanced Image Processing, Fall 2026")
    doc.build(report_pages(tree), onFirstPage=footer, onLaterPages=footer)


if __name__ == "__main__":
    main()
