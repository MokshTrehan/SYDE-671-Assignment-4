"""Build the code ZIP and the complete offline submission."""
from pathlib import Path
import shutil
from zipfile import ZIP_DEFLATED, ZipFile

from build_report import CODE, PDF, ROOT, SITE

OUTPUT = ROOT / "output"
SUBMISSION = "syde671-assignment4-submission.zip"
COMPONENTS = (
    "README.md", "requirements.txt", "p1.py", "p2.py", "p3.py", "p4.py",
    "epipolar_utils.py", "sfm_utils.py", "generate_results.py", "build_report.py",
    "export_pdf.py", "package_submission.py",
)


def put_files(zip_file, folder, paths, prefix=Path()):
    for path in paths:
        zip_file.write(path, (prefix / path.relative_to(folder)).as_posix())


def main():
    pdf = OUTPUT / "pdf" / PDF
    shutil.copyfile(pdf, SITE / "downloads" / PDF)
    assets = [SITE / "report.js", SITE / "style.css"]
    relevant_data = sorted(p for p in (ROOT / "data").rglob("*")
                           if p.is_file() and p.name != "copy_dense_matches.npy")
    with ZipFile(OUTPUT / CODE, "w", ZIP_DEFLATED) as code:
        put_files(code, ROOT, [ROOT / n for n in COMPONENTS] + relevant_data + assets)
        records = ROOT / "results"
        put_files(code, ROOT, [records / "measurements.json"])
    shutil.copyfile(OUTPUT / CODE, SITE / "downloads" / CODE)
    with ZipFile(OUTPUT / SUBMISSION, "w", ZIP_DEFLATED) as full:
        put_files(full, ROOT, [ROOT / "README.md"])
        put_files(full, ROOT, [pdf, OUTPUT / CODE])
        put_files(full, ROOT, sorted(p for p in SITE.rglob("*") if p.is_file()))


if __name__ == "__main__":
    main()
